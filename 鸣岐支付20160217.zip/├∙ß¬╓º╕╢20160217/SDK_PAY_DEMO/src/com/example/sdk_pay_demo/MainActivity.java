package com.example.sdk_pay_demo;

import java.util.Random;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.mq.pay.CallSdkListener;
import com.mq.pay.MQPay;
import com.mq.pay.QueryPayResultListener;
import com.tencent.tmgp.jhx.R;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Button btn = (Button)findViewById(R.id.button1);
		btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				final Bundle extras = new Bundle();
				String appid = "mq152823349e387837";
				String market = "401";
				extras.putString("appid", appid);//���appid
				extras.putString("market", market);//���������ţ�Ĭ��400
				extras.putString("userId", String.valueOf(System.currentTimeMillis()));//����,�û����
				extras.putString("nickname", "nickname"+new Random().nextInt(1000));//����ǳ�
				extras.putString("waresId", "waresId"+new Random().nextInt(1000));//�����Ʒ���
				extras.putString("wares", "wares"+new Random().nextInt(1000));//�����Ʒ����
				extras.putString("cpOrderId", "cpOrderId"+new Random().nextInt(10000));//��ѡ��CP������ţ����ظ�
				extras.putString("ext", "͸������"+new Random().nextInt(100));//��ѡ��͸��������ԭ������
				extras.putInt("totalFee", 1);//���֧������λ��
				extras.putString("wxappid", "wx28e6aaa8d86aaa08");//���΢��APPID������������΢��֧��
				
				MQPay.getInstance().onCallSdk(appid, market, new CallSdkListener() {
					
					@Override
					public void onResult(int sdkId) {
						Toast.makeText(MainActivity.this, String.valueOf(sdkId), Toast.LENGTH_SHORT).show();
						switch (sdkId) {
						case CallSdkListener.MQ_SDK:
							MQPay.getInstance().pay(MainActivity.this, extras);
							break;
						case CallSdkListener.MSDK:
							//call MSDK
							Toast.makeText(MainActivity.this, "call MSDK", Toast.LENGTH_SHORT).show();
							break;
						case CallSdkListener.PARAM_ERROR:
							Toast.makeText(MainActivity.this, "appid����market���ô���", Toast.LENGTH_SHORT).show();
							break;
						case CallSdkListener.UNKNOWN:
							Toast.makeText(MainActivity.this, "δ֪����", Toast.LENGTH_SHORT).show();
							break;
						default:
							break;
						}
						
					}
				});
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == 20000 && resultCode == 20000) {
    		String orderId = data.getStringExtra("orderId");
			MQPay.getInstance().onPayResult(orderId, new QueryPayResultListener() {
				
				@Override
				public void onResult(int result) {
					switch(result) {
						case 200:
							Toast.makeText(MainActivity.this, "֧���ɹ�"+result, Toast.LENGTH_SHORT).show();
							break;
						case 201:
							Toast.makeText(MainActivity.this, "��������"+result, Toast.LENGTH_SHORT).show();
							break;
						case 202:
							Toast.makeText(MainActivity.this, "������"+result, Toast.LENGTH_SHORT).show();
							break;
						case 203:
							Toast.makeText(MainActivity.this, "֧��ʧ��"+result, Toast.LENGTH_SHORT).show();
							break;
						case -2:
							Toast.makeText(MainActivity.this, "֧��ȡ��"+result, Toast.LENGTH_SHORT).show();
							break;
						case -1:
							Toast.makeText(MainActivity.this, "δ֪����"+result, Toast.LENGTH_SHORT).show();
							break;
						case 0:
							Toast.makeText(MainActivity.this, "�����쳣"+result, Toast.LENGTH_SHORT).show();
							break;
					}
				}
			});
    	}
	}

}
